package me.hindoong.cafeteria.dao;

import java.util.ArrayList;
import java.util.Map;

import me.hindoong.cafeteria.vo.MenuVO;

public interface MenuMapper {

	public int insertMenu(MenuVO menu);
	
	public int updateMenu(MenuVO menu);
	
	public int deleteMenu(int menunum);
	
	public MenuVO selectMenuOne(int menunum);
	
	public ArrayList<MenuVO> selectMenuList(String menuname);
	
}
