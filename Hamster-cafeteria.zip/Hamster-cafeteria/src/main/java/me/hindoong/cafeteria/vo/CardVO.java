package me.hindoong.cafeteria.vo;

public class CardVO {

	private int cardnum;
	private String cookdate;
	private int menunum;
	
	public CardVO() {
		super();
	}
	
	public CardVO(String cookdate, int menunum) {
		super();
		this.cookdate = cookdate;
		this.menunum = menunum;
	}

	public CardVO(int cardnum, String cookdate, int menunum) {
		super();
		this.cardnum = cardnum;
		this.cookdate = cookdate;
		this.menunum = menunum;
	}

	public int getCardnum() {
		return cardnum;
	}

	public void setCardnum(int cardnum) {
		this.cardnum = cardnum;
	}

	public String getCookdate() {
		return cookdate;
	}

	public void setCookdate(String cookdate) {
		this.cookdate = cookdate;
	}

	public int getMenunum() {
		return menunum;
	}

	public void setMenunum(int menunum) {
		this.menunum = menunum;
	}

	@Override
	public String toString() {
		return "CardVO [cardnum=" + cardnum + ", cookdate=" + cookdate + ", menunum=" + menunum + "]";
	}
	
}
