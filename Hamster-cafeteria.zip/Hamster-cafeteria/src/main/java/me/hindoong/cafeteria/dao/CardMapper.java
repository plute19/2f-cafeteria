package me.hindoong.cafeteria.dao;

import java.util.ArrayList;

import me.hindoong.cafeteria.vo.CardVO;

public interface CardMapper {

	public int insertCard(CardVO card);
	
	public int updateCard(CardVO card);
	
	public int deleteCard(String cookdate);
	
	public CardVO selectCardOne(int cardnum);
	
	public ArrayList<CardVO> selectCardList(String cookdate);
	
}
