package me.hindoong.cafeteria.dao;

import java.util.ArrayList;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class ManagerDAO implements ManagerMapper {

	@Inject
	SqlSession session;

	@Override
	public String isManager(String manageremail) {
		
		String result = null;
		
		try {
			result = session.getMapper(ManagerMapper.class).isManager(manageremail);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

}
