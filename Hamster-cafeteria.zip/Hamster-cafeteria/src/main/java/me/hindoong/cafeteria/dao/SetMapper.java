package me.hindoong.cafeteria.dao;

import me.hindoong.cafeteria.vo.SetVO;

public interface SetMapper {

	//menunum으로 검색합니다.
	public SetVO selectSet(int menunum);
	
}
