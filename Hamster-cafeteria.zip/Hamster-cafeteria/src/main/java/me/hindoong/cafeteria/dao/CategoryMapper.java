package me.hindoong.cafeteria.dao;

import java.util.ArrayList;

import me.hindoong.cafeteria.vo.CategoryVO;

public interface CategoryMapper {
	
	//카테고리는 정해둔 한식 일식 중식 양식 간식 퓨전 기타 등 7개를 넣는 것...?
	public int insertCategory(String categoryname);
	
	//특정 카테고리 정보만
	public CategoryVO selectCategoryOne(int caegorynum);
	
	//모든 카테고리 정보
	public ArrayList<CategoryVO> selectCategoryList();
	
}
