package me.hindoong.cafeteria.vo;

public class SetVO {

	private int menunum;
	private String menuname;
	private int categorynum;
	private String categoryname;
	private int good;
	private int total;
	private int categorygood;
	private int categorytotal;
	
	public SetVO() {}

	public SetVO(int menunum, String menuname, int categorynum, String categoryname, int good, int total,
			int categorygood, int categorytotal) {
		super();
		this.menunum = menunum;
		this.menuname = menuname;
		this.categorynum = categorynum;
		this.categoryname = categoryname;
		this.good = good;
		this.total = total;
		this.categorygood = categorygood;
		this.categorytotal = categorytotal;
	}

	public int getMenunum() {
		return menunum;
	}

	public void setMenunum(int menunum) {
		this.menunum = menunum;
	}

	public String getMenuname() {
		return menuname;
	}

	public void setMenuname(String menuname) {
		this.menuname = menuname;
	}

	public int getCategorynum() {
		return categorynum;
	}

	public void setCategorynum(int categorynum) {
		this.categorynum = categorynum;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public int getGood() {
		return good;
	}

	public void setGood(int good) {
		this.good = good;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getCategorygood() {
		return categorygood;
	}

	public void setCategorygood(int categorygood) {
		this.categorygood = categorygood;
	}

	public int getCategorytotal() {
		return categorytotal;
	}

	public void setCategorytotal(int categorytotal) {
		this.categorytotal = categorytotal;
	}

	@Override
	public String toString() {
		return "SetVO [menunum=" + menunum + ", menuname=" + menuname + ", categorynum=" + categorynum
				+ ", categoryname=" + categoryname + ", good=" + good + ", total=" + total + ", categorygood="
				+ categorygood + ", categorytotal=" + categorytotal + "]";
	};
	
}
