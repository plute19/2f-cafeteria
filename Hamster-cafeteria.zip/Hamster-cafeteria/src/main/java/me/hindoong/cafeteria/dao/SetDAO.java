package me.hindoong.cafeteria.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import me.hindoong.cafeteria.vo.SetVO;

@Repository
public class SetDAO implements SetMapper {

	@Inject
	SqlSession session;
	
	@Override
	public SetVO selectSet(int menunum) {
		
		SetVO set = null;
		
		try {
			set = session.getMapper(SetMapper.class).selectSet(menunum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return set;
		
	}
	
}
