package me.hindoong.cafeteria.dao;

public interface ManagerMapper {

	public String isManager(String manageremail);
}
