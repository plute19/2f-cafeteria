package me.hindoong.cafeteria.dao;

import me.hindoong.cafeteria.vo.RateVO;

public interface RateMapper {

	public int insertRate(RateVO rate);
	
	public int updateRate(RateVO rate);
	
	public int deleteRate(int ratenum);
	
	public RateVO selectRate(RateVO rate);
	
}
