package me.hindoong.cafeteria.vo;

public class CategoryVO {

	private int categorynum;
	private String categoryname;
	private int total;
	private int good;
	private int count;

	public CategoryVO() {
		super();
	}

	public CategoryVO(int categorynum, String categoryname, int total, int good, int count) {
		super();
		this.categorynum = categorynum;
		this.categoryname = categoryname;
		this.total = total;
		this.good = good;
		this.count = count;
	}

	public int getCategorynum() {
		return categorynum;
	}

	public void setCategorynum(int categorynum) {
		this.categorynum = categorynum;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getGood() {
		return good;
	}

	public void setGood(int good) {
		this.good = good;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "CategoryVO [categorynum=" + categorynum + ", categoryname=" + categoryname + ", total=" + total
				+ ", good=" + good + ", count=" + count + "]";
	}
	
}
