package me.hindoong.cafeteria.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import me.hindoong.cafeteria.vo.CardVO;

@Repository
public class CardDAO implements CardMapper {
	
	@Autowired
	SqlSession session;

	@Override
	public int insertCard(CardVO card) {
		
		int result = 0;
		
		try {
			result = session.getMapper(CardMapper.class).insertCard(card);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int updateCard(CardVO card) {
		
		int result = 0;
		
		try {
			result = session.getMapper(CardMapper.class).updateCard(card);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int deleteCard(String cookdate) {
		
		int result = 0;
		
		try {
			result = session.getMapper(CardMapper.class).deleteCard(cookdate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public CardVO selectCardOne(int cardnum) {
		
		CardVO card = null;
		
		try {
			card = session.getMapper(CardMapper.class).selectCardOne(cardnum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return card;
	}

	@Override
	public ArrayList<CardVO> selectCardList(String cookdate) {

		ArrayList<CardVO> cardList = null;
		
		try {
			cardList = session.getMapper(CardMapper.class).selectCardList(cookdate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return cardList;
	}

}
