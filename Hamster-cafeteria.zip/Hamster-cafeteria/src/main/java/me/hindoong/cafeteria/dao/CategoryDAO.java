package me.hindoong.cafeteria.dao;

import java.util.ArrayList;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import me.hindoong.cafeteria.vo.CategoryVO;

@Repository
public class CategoryDAO implements CategoryMapper {

	@Inject
	SqlSession session;
	
	private final String[] CATEGORIES = {"한식", "일식", "중식", "양식", "간식", "퓨전", "기타"};
	
	@Override
	public int insertCategory(String categoryname) {
		
		int result = 0;
		
		try {
			for (int i = 0; i < CATEGORIES.length; i++) {
				result += session.getMapper(CategoryMapper.class).insertCategory((CATEGORIES[i]));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	

	@Override
	public CategoryVO selectCategoryOne(int caegorynum) {
		
		CategoryVO category = null;
		
		try {
			category = session.getMapper(CategoryMapper.class).selectCategoryOne(caegorynum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return category;
	}

	@Override
	public ArrayList<CategoryVO> selectCategoryList() {
		
		ArrayList<CategoryVO> categories = new ArrayList<>();
		
		try {
			categories = session.getMapper(CategoryMapper.class).selectCategoryList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return categories;
	}

}
