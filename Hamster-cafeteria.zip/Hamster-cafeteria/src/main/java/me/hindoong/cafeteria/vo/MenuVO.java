package me.hindoong.cafeteria.vo;

public class MenuVO {

	private int menunum;
	private String menuname;
	private int categorynum;
	private String categoryname;	// db에서 카테고리 이름 받아올 때 사용할 변수
	private int like;	// 좋아요 받은 개수
	private int total;	// 전체 평가 수
	private int count;	// 지금까지 요리되어 나온 횟수
	
	public MenuVO() {
		super();
	}

	public MenuVO(int menunum, String menuname, int categorynum, String categoryname, int like, int total, int count) {
		super();
		this.menunum = menunum;
		this.menuname = menuname;
		this.categorynum = categorynum;
		this.categoryname = categoryname;
		this.like = like;
		this.total = total;
		this.count = count;
	}

	public int getMenunum() {
		return menunum;
	}

	public void setMenunum(int menunum) {
		this.menunum = menunum;
	}

	public String getMenuname() {
		return menuname;
	}

	public void setMenuname(String menuname) {
		this.menuname = menuname;
	}

	public int getCategorynum() {
		return categorynum;
	}

	public void setCategorynum(int categorynum) {
		this.categorynum = categorynum;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public int getLike() {
		return like;
	}

	public void setLike(int like) {
		this.like = like;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "MenuVO [menunum=" + menunum + ", menuname=" + menuname + ", categorynum=" + categorynum
				+ ", categoryname=" + categoryname + ", like=" + like + ", total=" + total + ", count=" + count + "]";
	}
	
}
