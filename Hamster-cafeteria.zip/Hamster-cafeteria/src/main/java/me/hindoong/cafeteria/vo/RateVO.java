package me.hindoong.cafeteria.vo;

public class RateVO {
	
	private int ratenum;
	private int rate;
	private int menunum;
	private String memberemail;
	private String ratedate;
	
	public RateVO() {
		super();
	}
	
	public int getRatenum() {
		return ratenum;
	}



	public void setRatenum(int ratenum) {
		this.ratenum = ratenum;
	}



	public int getRate() {
		return rate;
	}



	public void setRate(int rate) {
		this.rate = rate;
	}



	public int getMenunum() {
		return menunum;
	}



	public void setMenunum(int menunum) {
		this.menunum = menunum;
	}



	public String getMemberemail() {
		return memberemail;
	}



	public void setMemberemail(String memberemail) {
		this.memberemail = memberemail;
	}



	public String getRatedate() {
		return ratedate;
	}



	public void setRatedate(String ratedate) {
		this.ratedate = ratedate;
	}



	public RateVO(int ratenum, int rate, int menunum, String memberemail, String ratedate) {
		super();
		this.ratenum = ratenum;
		this.rate = rate;
		this.menunum = menunum;
		this.memberemail = memberemail;
		this.ratedate = ratedate;
	}



	@Override
	public String toString() {
		return "RateVO [ratenum=" + ratenum + ", rate=" + rate + ", menunum=" + menunum + ", memberemail=" + memberemail
				+ ", ratedate=" + ratedate + "]";
	}

	

}
