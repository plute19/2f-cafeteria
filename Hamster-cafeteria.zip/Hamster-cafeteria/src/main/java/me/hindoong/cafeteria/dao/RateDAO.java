package me.hindoong.cafeteria.dao;

import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import me.hindoong.cafeteria.vo.RateVO;

@Repository
public class RateDAO implements RateMapper {
	
	@Inject
	private SqlSession session;

	@Override
	public int insertRate(RateVO rate) {
		
		int result = 0;
		
		try {
			result = session.getMapper(RateMapper.class).insertRate(rate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int updateRate(RateVO rate) {

		int result = 0;
		
		try {
			result = session.getMapper(RateMapper.class).updateRate(rate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int deleteRate(int ratenum) {

		int result = 0;
		
		try {
			result = session.getMapper(RateMapper.class).deleteRate(ratenum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public RateVO selectRate(RateVO ratevo) {

		RateVO rate = null;
		
		try {
			rate = session.getMapper(RateMapper.class).selectRate(ratevo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return rate;
	}

}
