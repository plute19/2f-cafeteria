package me.hindoong.cafeteria.dao;

import java.util.ArrayList;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import me.hindoong.cafeteria.vo.MenuVO;

@Repository
public class MenuDAO implements MenuMapper {
	
	@Inject
	SqlSession session;

	@Override
	public int insertMenu(MenuVO menu) {
		
		int result = 0;
		
		try {
			result = session.getMapper(MenuMapper.class).insertMenu(menu);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int updateMenu(MenuVO menu) {
		
		int result = 0;
		
		try {
			result = session.getMapper(MenuMapper.class).updateMenu(menu);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int deleteMenu(int menunum) {
		
		int result = 0;
		
		try {
			result = session.getMapper(MenuMapper.class).deleteMenu(menunum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public MenuVO selectMenuOne(int menunum) {

		MenuVO menu = null;
		
		try {
			menu = session.getMapper(MenuMapper.class).selectMenuOne(menunum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return menu;
		
	}

	@Override
	public ArrayList<MenuVO> selectMenuList(String menuname) {
		
		ArrayList<MenuVO> menuList = null;
		
		try {
			menuList = session.getMapper(MenuMapper.class).selectMenuList(menuname);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return menuList;
	}

}
