package me.hindoong.cafeteria.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

import me.hindoong.cafeteria.dao.CardDAO;
import me.hindoong.cafeteria.dao.CategoryDAO;
import me.hindoong.cafeteria.dao.ManagerDAO;
import me.hindoong.cafeteria.dao.MenuDAO;
import me.hindoong.cafeteria.dao.RateDAO;
import me.hindoong.cafeteria.dao.SetDAO;
import me.hindoong.cafeteria.vo.CardVO;
import me.hindoong.cafeteria.vo.CategoryVO;
import me.hindoong.cafeteria.vo.MenuVO;
import me.hindoong.cafeteria.vo.RateVO;
import me.hindoong.cafeteria.vo.SetVO;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	private CardDAO cardDAO;
	@Autowired
	private SetDAO setDAO;
	@Autowired
	private RateDAO rateDAO;
	@Autowired
	private ManagerDAO managerDAO;
	@Autowired
	private MenuDAO menuDAO;
	@Autowired
	private CategoryDAO categoryDAO;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		return "home";
	}
	
	@ResponseBody
	@RequestMapping(value = "getSet", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String getSet(String mon, String tue, String wed, String thu, String fri, String cookdate) {
		
		String[] week = {mon, tue, wed, thu, fri};
		
		if (cookdate == null) {
			// 주간 식단표 리턴
			
			// 값을 담아 보낼 맵
			HashMap<String, ArrayList<SetVO>> setMap = new HashMap<>();
			
			for (int i = 0; i < week.length; i++) {
				ArrayList<CardVO> cardList = cardDAO.selectCardList(week[i]);
				
				ArrayList<SetVO> setList = new ArrayList<>();
				for (CardVO card : cardList) {
					int menunum = card.getMenunum();
					SetVO set = setDAO.selectSet(menunum);
					setList.add(set);
				}
				if (setList.size() > 0) {
					setMap.put(week[i], setList);
				}
			}
			
			Gson gson = new Gson();
			
			return setMap.size()==0? "":gson.toJson(setMap);
		} else {
			// 하루 식단표만 리턴

			ArrayList<CardVO> cardList = cardDAO.selectCardList(cookdate);
			
			ArrayList<SetVO> setList = new ArrayList<>();
			for (CardVO card : cardList) {
				int menunum = card.getMenunum();
				SetVO set = setDAO.selectSet(menunum);
				setList.add(set);
			}
		
			Gson gson = new Gson();
			
			String result = gson.toJson(setList);
			
			return result;
		}
		
	}
	
	@ResponseBody
	@RequestMapping(value = "insertRate", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String insertRate(String menunum, String memberemail, String rate, String ratedate) {
		
		int result = 0;
		
		RateVO ratevo = new RateVO();
		RateVO resultRate = null;
		
		try {
			Integer menunum_i = Integer.parseInt(menunum);
			Integer rate_i = Integer.parseInt(rate);
			
			ratevo.setMenunum(menunum_i);
			ratevo.setRate(rate_i);
			ratevo.setMemberemail(memberemail);
			ratevo.setRatedate(ratedate);
			
			resultRate = rateDAO.selectRate(ratevo);
			
			if (resultRate != null) {
				//이미 평가한 메뉴이므로 그 평가를 삭제
				result = rateDAO.deleteRate(resultRate.getRatenum());
			} else {
				//평가하지 않은 메뉴이므로 평가 등록
				result = rateDAO.insertRate(ratevo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result==1? "success":"fail";
	}
	
	@ResponseBody
	@RequestMapping(value = "isManager", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String isManager(String manageremail) {
		
		String result = "no";
		
		if (manageremail == null) {
			return result;
		}
		
		if (managerDAO.isManager(manageremail) != null) {
			result = "isManager";
		}
		
		return result;
	}
	
	@ResponseBody
	@RequestMapping(value = "insertCard", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String insertCard(String[] menunumList) {
		
		int result = 0;
		
		if (menunumList == null) {
			return result+"";
		}
		
		String cookdate = menunumList[0];
	
		cardDAO.deleteCard(cookdate);
		
		for (int i = 1; i < menunumList.length; i++) {
			CardVO card = new CardVO(cookdate, Integer.parseInt(menunumList[i]));
			result += cardDAO.insertCard(card);
		}
		
		return result+"";
	}
	
	@ResponseBody
	@RequestMapping(value = "selectMenuList", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String selectMenuList(String menuname) {
		
		if (menuname == null || menuname.length() == 0) {
			return "no";
		}
		
		ArrayList<MenuVO> menuList = menuDAO.selectMenuList(menuname);
	
		Gson gson = new Gson();
		
		String result = gson.toJson(menuList);
		
		return result;
	}
	
	@ResponseBody
	@RequestMapping(value = "selectCategory", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String selectCategory() {
		
		ArrayList<CategoryVO> categoryList = categoryDAO.selectCategoryList();
	
		Gson gson = new Gson();
		
		String result = gson.toJson(categoryList);
		
		return result;
	}
	
	@ResponseBody
	@RequestMapping(value = "insertMenu", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String insertMenu(MenuVO menu) {
		
		if (menu == null) return "fail";
		
		int result = menuDAO.insertMenu(menu);
		
		return result == 1? "success":"fail";
	}
	
	@ResponseBody
	@RequestMapping(value = "removeMenu", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
	public String removeMenu(String menunum) {
		
		int result = 0;
		
		if (menunum == null) return "fail";
		
		try {
			result = menuDAO.deleteMenu(Integer.parseInt(menunum));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result == 1? "success":"fail";
	}
	
}
